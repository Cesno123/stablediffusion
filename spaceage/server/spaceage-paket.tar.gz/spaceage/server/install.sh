#!/bin/bash
# Sets up SpaceAge on a fresh Ubuntu 24.04 server (run as root from /opt/spaceage).
# Expects /etc/spaceage.env with IG_ACCESS_TOKEN and BFL_API_KEY.
set -euo pipefail
APP=/opt/spaceage

timedatectl set-timezone Europe/Berlin
# 2 GB swap as a safety net: building a reel needs ~0.6 GB for ffmpeg
if [ ! -f /swapfile ]; then
	fallocate -l 2G /swapfile && chmod 600 /swapfile && mkswap /swapfile && swapon /swapfile
	echo "/swapfile none swap sw 0 0" >> /etc/fstab
fi
# wait for the first-boot automatic updates instead of failing on the dpkg lock
apt-get -o DPkg::Lock::Timeout=900 update
DEBIAN_FRONTEND=noninteractive apt-get -o DPkg::Lock::Timeout=900 install -y python3-venv caddy cron curl ffmpeg
python3 -m venv "$APP/venv"
"$APP/venv/bin/pip" install --quiet requests pillow numpy

id spaceage >/dev/null 2>&1 || useradd --system --home-dir /var/lib/spaceage --shell /usr/sbin/nologin spaceage
mkdir -p /var/lib/spaceage /srv/spaceage/www "$APP/spaceage/queue" "$APP/spaceage/posted"
touch /var/log/spaceage.log
chown -R spaceage: /var/lib/spaceage /srv/spaceage/www "$APP/spaceage/queue" "$APP/spaceage/posted" /var/log/spaceage.log
chmod +x "$APP/spaceage/server/run.sh"

# Public HTTPS address without an own domain: <ip>.sslip.io, certificate by Caddy
ip=$(curl -4 -fsS https://api.ipify.org)
host="${ip//./-}.sslip.io"
# Upload page for own images: https://$host/upload, user "spaceage" + password
pwfile=/root/spaceage-upload-passwort.txt
[ -s "$pwfile" ] || { tr -dc 'a-z2-9' < /dev/urandom | head -c 12 > "$pwfile"; chmod 600 "$pwfile"; }
pwhash=$(caddy hash-password --plaintext "$(cat "$pwfile")")
cat > /etc/caddy/Caddyfile <<CADDY
$host {
	handle /upload* {
		basicauth {
			spaceage $pwhash
		}
		reverse_proxy 127.0.0.1:8081
	}
	handle {
		root * /srv/spaceage/www
		file_server
	}
}
CADDY
cat > /etc/systemd/system/spaceage-upload.service <<UNIT
[Unit]
Description=SpaceAge upload page
After=network.target

[Service]
User=spaceage
ExecStart=$APP/venv/bin/python $APP/spaceage/server/upload.py
Restart=always

[Install]
WantedBy=multi-user.target
UNIT
systemctl daemon-reload
systemctl enable spaceage-upload
systemctl restart spaceage-upload
systemctl restart caddy
grep -q '^SPACEAGE_PUBLIC_URL=' /etc/spaceage.env || echo "SPACEAGE_PUBLIC_URL=https://$host" >> /etc/spaceage.env
chown root:spaceage /etc/spaceage.env
chmod 640 /etc/spaceage.env

# 8 posts a day, every 2 hours 8:07-22:07 (Berlin time)
cat > /etc/cron.d/spaceage <<CRON
7 8-22/2 * * * spaceage $APP/spaceage/server/run.sh >> /var/log/spaceage.log 2>&1
CRON

# First check: is the Instagram token ok? Result on https://$host/status.txt
sleep 20  # give Caddy time for the certificate
runuser -u spaceage -- "$APP/spaceage/server/run.sh" --check >> /var/log/spaceage.log 2>&1 || true
echo "FERTIG: https://$host/status.txt - Uploads: https://$host/upload"
# setup log page on port 8080 is no longer needed
systemctl stop spaceage-setup || true
